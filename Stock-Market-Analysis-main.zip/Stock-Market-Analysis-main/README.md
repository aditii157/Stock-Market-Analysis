# Stock-Market-Analysis
Implemented GARCH model to observe volatility trends for 13 Stock Indices and compared with 6 rolling indices
Performed portfolio optimization & obtained min Risk and max Sharpe ratio portfolio among 50k combinations
